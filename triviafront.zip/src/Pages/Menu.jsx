export default function Game() {
  return (
    <div>Game</div>
  )
}